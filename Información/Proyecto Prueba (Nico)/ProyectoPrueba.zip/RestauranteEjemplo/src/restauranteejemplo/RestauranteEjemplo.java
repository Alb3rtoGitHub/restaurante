/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restauranteejemplo;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import restauranteejemplo.AccesoADatos.MesaData;
import restauranteejemplo.AccesoADatos.PedidoData;
import restauranteejemplo.AccesoADatos.PedidoProductoData;
import restauranteejemplo.AccesoADatos.ProductoData;
import restauranteejemplo.entidades.Mesa;
import restauranteejemplo.entidades.Pedido;
import restauranteejemplo.entidades.PedidoProducto;
import restauranteejemplo.entidades.Producto;


/**
 *
 * @author Nico
 */
public class RestauranteEjemplo {

    public static void main(String[] args) {
        /* MESA */
        MesaData mesadata = new MesaData();
        
        /*GUARDAR MESA*/
        //Mesa newmesa = new Mesa(6, 5, false, true); //False = Ocupada - True = Libre;
        //mesadata.guardarMesa(newmesa);
        
        /*MODIFICAR MESA*/
        //Mesa modmesa = new Mesa(4, 7, 6, true, true);
        //mesadata.modificarMesa(modmesa);
        
        /*ELIMINAR MESA*/
        //mesadata.eliminarMesa(3);
        
        /*BUSCAR MESA POR ID*/
        //System.out.println(mesadata.buscarMesa(1));
        
        /*BUSCAR MESA POR NUMERO*/
        //System.out.println(mesadata.buscarMesaPorNumero(3));
        
        /*LISTAR MESAS*/
        //for (Mesa listarMesas : mesadata.listarMesas()) {
        //    System.out.println(listarMesas);
        //    System.out.println("");
        //}
        
        /* ######################################## */
        
        /* PEDIDO */
        PedidoData pedidodata = new PedidoData();
        
        /* REGISTRAR PEDIDO */
        //Pedido newpedido = new Pedido(mesadata.buscarMesa(2), "Jorge", LocalDateTime.now(), 0, false); //Al realizar un pedido a una Mesa libre (1 o true) debera pasar a Ocupada (0 o false);
        //pedidodata.registrarPedido(newpedido);
        
        /* MODIFICAR PEDIDO */
        //Pedido modpedido = new Pedido(4, mesadata.buscarMesa(4), "Pepito", LocalDateTime.of(2023, 10, 10, 16, 15, 18), 0, false);
        //pedidodata.modificarPedido(modpedido);
        
        /* ELIMINAR PEDIDO */
        //pedidodata.eliminarPedido(2);
        
        /* BUSCAR PEDIDO */
        /*
        Pedido buscado = pedidodata.buscarPedido(1);
            System.out.println("ID: " + buscado.getIdPedido());
            System.out.println("Mesa: " + buscado.getMesa().getNumMesa());
            System.out.println("Nombre Mesero: " + buscado.getNombreMesero());
            System.out.println("Fecha: " + buscado.getFechaCreacion());
            System.out.println("Importe: " + buscado.getImporte());
            System.out.println("Cobrado: " + buscado.isCobrado());
            System.out.println("");
        */
        
        /* LISTAR PEDIDOS */
        /*
        for (Pedido listarPedidos : pedidodata.listarPedidos()) {
            System.out.println("ID: " + listarPedidos.getIdPedido());
            System.out.println("Mesa: " + listarPedidos.getMesa().getNumMesa());
            System.out.println("Nombre Mesero: " + listarPedidos.getNombreMesero());
            System.out.println("Fecha: " + listarPedidos.getFechaCreacion());
            System.out.println("Importe: " + listarPedidos.getImporte());
            System.out.println("Cobrado: " + listarPedidos.isCobrado());
            System.out.println("");
        }
        */
        
        /* LISTAR PEDIDOS POR MESA */
        /*
        for (Pedido pedidos : pedidodata.listarPedidoPorMesa(1)) {
            
            System.out.println("ID: " + pedidos.getIdPedido());
            System.out.println("Mesa: " + pedidos.getMesa().getNumMesa());
            System.out.println("Nombre Mesero: " + pedidos.getNombreMesero());
            System.out.println("Fecha: " + pedidos.getFechaCreacion());
            System.out.println("Importe: " + pedidos.getImporte());
            System.out.println("Cobrado: " + pedidos.isCobrado());
            System.out.println("");
        }
        */
        
        /* PRODUCTO */
        ProductoData productoData = new ProductoData();
        
        /* GUARDAR PRODUCTO */
        //Producto newproducto = new Producto("BS002", "Gaseosa", 400, 500, true);
        //productoData.guardarProducto(newproducto);
        
        /* MODIFICAR PRODUCTO */
        //Producto modproducto = new Producto(4, "BS002", "Coca Cola", 1100, 500, true);
        //productoData.modificarProducto(modproducto);
        
        /* ELIMINAR PRODUCTO */
        //productoData.eliminarProducto(4);
        
        /* BUSCAR PRODUCTO */
        //System.out.println(productoData.buscarProducto(1));
        
        /* BUSCAR PRODUCTO POR CODIGO */
        //System.out.println(productoData.buscarProductoPorCodigo("C002"));
        
        /* LISTA DE PRODUCTOS */
        /*
        for (Producto listarProducto : productoData.listarProductos()) {
            System.out.println(listarProducto);
            System.out.println("");
        }
        */
        
        /* PEDIDO PRODUCTO */
        PedidoProductoData ppData = new PedidoProductoData();
        
        /* GUARDAR PEDIDO PRODUCTO */
        
        /*
        PedidoProducto newpp = new PedidoProducto(pedidodata.buscarPedido(3), productoData.buscarProducto(2), 3);
        PedidoProducto newpp2 = new PedidoProducto(pedidodata.buscarPedido(1), productoData.buscarProducto(3), 1);
        
        ppData.agregarPedidoProducto(newpp);
        ppData.agregarPedidoProducto(newpp2);
        */
        
        /* MODIFICAR PEDIDO PRODUCTO */
        //PedidoProducto modpp = new PedidoProducto(6, pedidodata.buscarPedido(1), productoData.buscarProducto(2), 1);
        //ppData.modificarPedidoConProducto(modpp);
        
        /* ELIMINAR PEDIDO PRODUCTO */
        //ppData.eliminarPedidoConProducto(6);
        
        /* BUSCAR PEDIDO PRODUCTO */
        
        /*
        PedidoProducto buscado = ppData.buscarPedidoConProducto(5);
        System.out.println("ID: " + buscado.getIdPedidoProducto());
        System.out.println("Mesa: " + buscado.getPedido().getMesa().getNumMesa());
        System.out.println("Mesero: " + buscado.getPedido().getNombreMesero());
        System.out.println("Producto: " + buscado.getProducto().getNombreProducto());
        System.out.println("Cantidad: " + buscado.getCantidad());
        */
        
        /* LISTA PEDIDO PRODUCTO */
        /*
        for (PedidoProducto PedidosProductos : ppData.obtenerPedidosConProductos()) {
            System.out.println("ID: " + PedidosProductos.getIdPedidoProducto());
            System.out.println("Mesa: " + PedidosProductos.getPedido().getMesa().getNumMesa());
            System.out.println("Producto: " + PedidosProductos.getProducto().getNombreProducto());
            System.out.println("Cantidad: " + PedidosProductos.getCantidad());
            System.out.println("");
        }
        */
        
        /* LISTA PEDIDOS POR MESERO */
        /*
        for (Pedido ppXMesero : ppData.obtenerPedidosXMesero("Rojan")) {
            System.out.println("ID Pedido: " + ppXMesero.getIdPedido());
            System.out.println("Mesero: " + ppXMesero.getNombreMesero());
            System.out.println("Mesa: " + ppXMesero.getMesa().getNumMesa());
            System.out.println("Fecha: " + ppXMesero.getFechaCreacion());
            System.out.println("Importe: " + ppXMesero.getImporte());
            System.out.println("");
        }
        */
        
        /* CALCULAR SUBTOTAL DE UN PEDIDO PRODUCTO */
        //System.out.println("Subtotal: " + ppData.calcularSubtotal(2)); ;
        
        /* CALCULAR TOTAL DE UN PEDIDO */
        //System.out.println("Total: "  + ppData.calcularTotal(1));
        
        /* TOTAL EN UN DIA */
        //System.out.println("Total: " + ppData.precioTotalXFecha(LocalDate.of(2023, 10, 10))); //Posible metodo pero no puedo buscar por fecha;
        
        /* LISTAR PEDIDOS MESEROS EN FECHA */
        /*
        for (Pedido pedidosMeseros : ppData.listarPedidosXMeseroYFecha("Rojan", LocalDate.of(2023, 10, 8))) {
            System.out.println("ID: " + pedidosMeseros.getIdPedido());
            System.out.println("Numero Mesa: " + pedidosMeseros.getMesa().getNumMesa());
            System.out.println("Nombre Mesero: " + pedidosMeseros.getNombreMesero());
            System.out.println("Fecha: " + pedidosMeseros.getFechaCreacion());
            System.out.println("Importe: " + pedidosMeseros.getImporte());
        }
        */
        
        /* LISTAR PEDIDOS MESA ENTRE FECHA Y HORA */
        /*
        for (Pedido pedidofh : ppData.listarPedidosXMesaEntreFechaYHora(1, LocalDateTime.of(2023, 10, 8, 10, 26, 00), LocalDateTime.of(2023, 10, 11, 10, 30, 00))) {
            System.out.println("ID: " + pedidofh.getIdPedido());
            System.out.println("Mesa: " + pedidofh.getMesa().getIdMesa());
            System.out.println("Mesero: " + pedidofh.getNombreMesero());
            System.out.println("Fecha y Hora: " + pedidofh.getFechaCreacion());
            System.out.println("");
        }
        */
        
        /* LISTAR PEDIDOS PRODUCTOS POR PEDIDO */
        /*
        for (PedidoProducto pp : ppData.obtenerPPXPedido(1)) {
            System.out.println("ID " + pp.getIdPedidoProducto());
            System.out.println("Producto " + pp.getProducto().getNombreProducto());
            System.out.println("Precio " + pp.getProducto().getPrecio());
            System.out.println("Cantidad " + pp.getCantidad());
            System.out.println("");
        }
        */
    }
    
}
