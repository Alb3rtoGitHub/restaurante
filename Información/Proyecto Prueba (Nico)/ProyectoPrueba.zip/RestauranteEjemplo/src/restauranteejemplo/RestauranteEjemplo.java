/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restauranteejemplo;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import restauranteejemplo.AccesoADatos.MesaData;
import restauranteejemplo.AccesoADatos.PedidoData;
import restauranteejemplo.AccesoADatos.PedidoProductoData;
import restauranteejemplo.AccesoADatos.ProductoData;
import restauranteejemplo.entidades.Mesa;
import restauranteejemplo.entidades.Pedido;
import restauranteejemplo.entidades.PedidoProducto;
import restauranteejemplo.entidades.Producto;


/**
 *
 * @author Nico
 */
public class RestauranteEjemplo {

    public static void main(String[] args) {
        /* MESA */
        MesaData mesadata = new MesaData();
        
        /*GUARDAR MESA*/
        //Mesa newmesa = new Mesa(4, 3, false, true);
        //mesadata.guardarMesa(newmesa);
        
        /*MODIFICAR MESA*/
        //Mesa modmesa = new Mesa(1, 3, 4, false, true);
        //mesadata.modificarMesa(modmesa);
        
        /*ELIMINAR MESA*/
        //mesadata.eliminarMesa(2);
        
        /*BUSCAR MESA POR ID*/
        //System.out.println(mesadata.buscarMesa(1));
        
        /*BUSCAR MESA POR NUMERO*/
        //System.out.println(mesadata.buscarMesaPorNumero(4));
        
        /*LISTAR MESAS*/
        //for (Mesa listarMesas : mesadata.listarMesas()) {
        //    System.out.println(listarMesas);
        //    System.out.println("");
        //}
        
        /* ######################################## */
        
        /* PEDIDO */
        PedidoData pedidodata = new PedidoData();
        
        /* GUARDAR PEDIDO */
        //Pedido newpedido = new Pedido(mesadata.buscarMesa(1), "Rojan", LocalDateTime.now(), 0, false);
        //pedidodata.registrarPedido(newpedido);
        
        /* MODIFICAR PEDIDO */
        //Pedido modpedido = new Pedido(1, mesadata.buscarMesa(1), "Rojan", LocalDateTime.of(2023, 10, 8, 10, 26, 18), 2000, false);
        //pedidodata.modificarPedido(modpedido);
        
        /* ELIMINAR PEDIDO */
        //pedidodata.eliminarPedido(1);
        
        /* BUSCAR PEDIDO */
        /*
        Pedido buscado = pedidodata.buscarPedido(1);
            System.out.println("ID: " + buscado.getIdPedido());
            System.out.println("Mesa: " + buscado.getMesa().getNumMesa());
            System.out.println("Nombre Mesero: " + buscado.getNombreMesero());
            System.out.println("Fecha: " + buscado.getFechaCreacion());
            System.out.println("Importe: " + buscado.getImporte());
            System.out.println("Cobrado: " + buscado.isCobrado());
            System.out.println("");
        */
        
        /* LISTAR PEDIDOS */
        /*
        for (Pedido listarPedidos : pedidodata.listarPedidos()) {
            System.out.println("ID: " + listarPedidos.getIdPedido());
            System.out.println("Mesa: " + listarPedidos.getMesa().getNumMesa());
            System.out.println("Nombre Mesero: " + listarPedidos.getNombreMesero());
            System.out.println("Fecha: " + listarPedidos.getFechaCreacion());
            System.out.println("Importe: " + listarPedidos.getImporte());
            System.out.println("Cobrado: " + listarPedidos.isCobrado());
            System.out.println("");
        }
        */
        
        /* LISTAR PEDIDOS POR MESA */
        /*
        for (Pedido pedidos : pedidodata.listarPedidoPorMesa(1)) {
            
            System.out.println("ID: " + pedidos.getIdPedido());
            System.out.println("Mesa: " + pedidos.getMesa().getNumMesa());
            System.out.println("Nombre Mesero: " + pedidos.getNombreMesero());
            System.out.println("Fecha: " + pedidos.getFechaCreacion());
            System.out.println("Importe: " + pedidos.getImporte());
            System.out.println("Cobrado: " + pedidos.isCobrado());
            System.out.println("");
        }
        */
        
        /* PRODUCTO */
        ProductoData productoData = new ProductoData();
        
        /* GUARDAR PRODUCTO */
        //Producto newproducto = new Producto("BS001", "Agua", 400, 500, true);
        //productoData.guardarProducto(newproducto);
        
        /* MODIFICAR PRODUCTO */
        //Producto modproducto = new Producto(1, "C001", "Pizza", 1150.5, 150, true);
        //productoData.modificarProducto(modproducto);
        
        /* ELIMINAR PRODUCTO */
        //productoData.eliminarProducto(1);
        
        /* BUSCAR PRODUCTO */
        //System.out.println(productoData.buscarProducto(1));
        
        /* BUSCAR PRODUCTO POR CODIGO */
        //System.out.println(productoData.buscarProductoPorCodigo("C002"));
        
        /* LISTA DE PRODUCTOS */
        /*
        for (Producto listarProducto : productoData.listarProductos()) {
            System.out.println(listarProducto);
            System.out.println("");
        }
        */
        
        /* PEDIDO PRODUCTO */
        PedidoProductoData ppData = new PedidoProductoData();
        
        /* GUARDAR PEDIDO PRODUCTO */
        
        /*
        PedidoProducto newpp = new PedidoProducto(pedidodata.buscarPedido(2), productoData.buscarProducto(2), 4);
        PedidoProducto newpp2 = new PedidoProducto(pedidodata.buscarPedido(1), productoData.buscarProducto(2), 1);
        
        ppData.agregarPedidoProducto(newpp);
        ppData.agregarPedidoProducto(newpp2);
        */
        
        /* MODIFICAR PEDIDO PRODUCTO */
        //PedidoProducto modpp = new PedidoProducto(2, pedidodata.buscarPedido(1), productoData.buscarProducto(3), 3);
        //ppData.modificarPedidoConProducto(modpp);
        
        /* ELIMINAR PEDIDO PRODUCTO */
        //ppData.eliminarPedidoConProducto(1);
        
        /* BUSCAR PEDIDO PRODUCTO */
        
        /*
        PedidoProducto buscado = ppData.buscarPedidoConProducto(1);
        System.out.println("ID: " + buscado.getIdPedidoProducto());
        System.out.println("Mesa: " + buscado.getPedido().getMesa().getNumMesa());
        System.out.println("Mesero: " + buscado.getPedido().getNombreMesero());
        System.out.println("Producto: " + buscado.getProducto().getNombreProducto());
        System.out.println("Cantidad: " + buscado.getCantidad());
        */
        
        /* LISTA PEDIDO PRODUCTO */
        /*
        for (PedidoProducto PedidosProductos : ppData.obtenerPedidosConProductos()) {
            System.out.println("ID: " + PedidosProductos.getIdPedidoProducto());
            System.out.println("Mesa: " + PedidosProductos.getPedido().getMesa().getNumMesa());
            System.out.println("Producto: " + PedidosProductos.getProducto().getNombreProducto());
            System.out.println("Cantidad: " + PedidosProductos.getCantidad());
            System.out.println("");
        }
        */
        
        /* LISTA PEDIDOS POR MESERO */
        /*
        for (Pedido ppXMesero : ppData.obtenerPedidosXMesero("Rojan")) {
            System.out.println("ID Pedido: " + ppXMesero.getIdPedido());
            System.out.println("Mesero: " + ppXMesero.getNombreMesero());
            System.out.println("Mesa: " + ppXMesero.getMesa().getNumMesa());
            System.out.println("Fecha: " + ppXMesero.getFechaCreacion());
            System.out.println("Importe: " + ppXMesero.getImporte());
            System.out.println("");
        }
        */
        
        /* CALCULAR SUBTOTAL */
        //System.out.println("Subtotal: " + ppData.calcularSubtotal(2)); ;
        
        /* CALCULAR TOTAL */
        //System.out.println("Total: "  + ppData.calcularTotal(1, 1));
        
        /* TOTAL EN UN DIA */
        //System.out.println("Total: " + ppData.precioTotalXFecha(LocalDate.of(2023, 10, 7), LocalDate.of(2023, 10, 9))); //Posible metodo pero no puedo buscar por fecha;
        
        /* LISTAR PEDIDOS MESEROS EN FECHA */
        /*
        for (Pedido pedidosMeseros : ppData.listarPedidosXMeseroYFecha("Rojan", LocalDate.of(2023, 10, 7), LocalDate.of(2023, 10, 9))) {
            System.out.println("ID: " + pedidosMeseros.getIdPedido());
            System.out.println("Numero Mesa: " + pedidosMeseros.getMesa().getNumMesa());
            System.out.println("Nombre Mesero: " + pedidosMeseros.getNombreMesero());
            System.out.println("Fecha: " + pedidosMeseros.getFechaCreacion());
            System.out.println("Importe: " + pedidosMeseros.getImporte());
        }
        */
        
        /* LISTAR PEDIDOS MESA ENTRE FECHA Y HORA */
        /*
        for (Pedido pedidofh : ppData.listarPedidosXMesaEntreFechaYHora(1, LocalDateTime.of(2023, 10, 8, 10, 26, 00), LocalDateTime.of(2023, 10, 11, 10, 30, 00))) {
            System.out.println("ID: " + pedidofh.getIdPedido());
            System.out.println("Mesa: " + pedidofh.getMesa().getIdMesa());
            System.out.println("Mesero: " + pedidofh.getNombreMesero());
            System.out.println("Fecha y Hora: " + pedidofh.getFechaCreacion());
            System.out.println("");
        }
        */
    }
    
}
