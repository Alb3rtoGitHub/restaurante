
package restauranteejemplo.views;

import restauranteejemplo.entidades.Mesa;


public class InternalFrameImagen extends PedidosV{
    private PanelPhoto p1 = new PanelPhoto();

    public InternalFrameImagen(Mesa mesita) {
        super(mesita);
        setContentPane(p1);
    }

    public void setImagen(String nombreImagen){
        p1.setImage(nombreImagen);
    }
}
