
package restauranteejemplo.views;

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JPanel;


public class PanelPhoto extends JPanel {
    
    private Image imagen;
    
    public PanelPhoto(){
        imagen = null;
    }
    
    public PanelPhoto(String nombreImagen){
        if (nombreImagen != null) {
            imagen = new ImageIcon(getClass().getResource(nombreImagen)).getImage();
            
        }
    }
    
    public void setImage(String nombre){
        if (nombre != null) {
            imagen = new ImageIcon(getClass().getResource(nombre)).getImage();
        } else {
            imagen = null;
        }
        repaint();
    }
    
    @Override
    public void paint( Graphics g){
        if (imagen != null) {
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
        }
        super.paint(g);
    }
}
