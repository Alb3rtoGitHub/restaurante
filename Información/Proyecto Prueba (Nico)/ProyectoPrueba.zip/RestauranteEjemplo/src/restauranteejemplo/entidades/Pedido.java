/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restauranteejemplo.entidades;

import java.time.LocalDateTime;
import java.util.Date;

/**
 *
 * @author Emiliano
 */
public class Pedido {
    
    private int idPedido;
    private Mesa mesa; //Seria el id para relacionarlo en que mesa se hizo el pedido;
    private String nombreMesero;
    private LocalDateTime fechaCreacion; //Pide poder visualizar pedidos por fecha;
    private double importe;
    private boolean cobrado; //Este estado va para si se ha cobrado o no el pedido;
    
    public Pedido() {
    }

    public Pedido(Mesa mesa, String nombreMesero, LocalDateTime fechaCreacion, double importe, boolean cobrado) {
        this.mesa = mesa;
        this.nombreMesero = nombreMesero;
        this.fechaCreacion = fechaCreacion;
        this.importe = importe;
        this.cobrado = cobrado;
    }

    public Pedido(int idPedido, Mesa mesa, String nombreMesero, LocalDateTime fechaCreacion, double importe, boolean cobrado) {
        this.idPedido = idPedido;
        this.mesa = mesa;
        this.nombreMesero = nombreMesero;
        this.fechaCreacion = fechaCreacion;
        this.importe = importe;
        this.cobrado = cobrado;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public Mesa getMesa() {
        return mesa;
    }

    public void setMesa(Mesa mesa) {
        this.mesa = mesa;
    }

    public String getNombreMesero() {
        return nombreMesero;
    }

    public void setNombreMesero(String nombreMesero) {
        this.nombreMesero = nombreMesero;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public double getImporte() {
        return importe;
    }

    public void setImporte(double importe) {
        this.importe = importe;
    }

    public boolean isCobrado() {
        return cobrado;
    }

    public void setCobrado(boolean cobrado) {
        this.cobrado = cobrado;
    }

    @Override
    public String toString() {
        return "############### \nPedido: " + idPedido + "\nMesa: " + mesa + "\nNombreMesero: " + nombreMesero + "\nFechaCreacion: " + fechaCreacion + "\nImporte: " + importe + "\nCobrado: " + cobrado;
    }
    
}
