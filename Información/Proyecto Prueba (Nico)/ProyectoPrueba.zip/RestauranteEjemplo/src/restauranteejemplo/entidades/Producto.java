/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restauranteejemplo.entidades;

/**
 *
 * @author Alberto
 */
public class Producto {
    
    private int idProducto;
    private String codigo;
    private String nombreProducto; //Del plato/comida;
    private double precio;
    private int stock;
    private boolean estadoProducto;

    public Producto() {
    }

    public Producto(String codigo, String nombreProducto, double precio, int stock, boolean estadoProducto) {
        this.codigo = codigo;
        this.nombreProducto = nombreProducto;
        this.stock = stock;
        this.precio = precio;
        this.estadoProducto = estadoProducto;
    }

    public Producto(int idProducto, String codigo, String nombreProducto, double precio, int stock, boolean estadoProducto) {
        this.idProducto = idProducto;
        this.codigo = codigo;
        this.nombreProducto = nombreProducto;
        this.stock = stock;
        this.precio = precio;
        this.estadoProducto = estadoProducto;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public boolean isEstadoProducto() {
        return estadoProducto;
    }

    public void setEstadoProducto(boolean estadoProducto) {
        this.estadoProducto = estadoProducto;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    @Override
    public String toString() {
        return "ID: " + idProducto + " - " + nombreProducto + " - " + precio + " $ - " + estadoProducto;
    }
    
    
}
