/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restauranteejemplo.entidades;


/**
 *
 * @author Melany
 */
public class Mesa {
    
    private int idMesa; //Seria el id;
    private int numMesa; //Numero de la mesa;
    private int capacidad; //Cantidad de personas;
    private boolean disponibilidad; //Si esta libre u ocupada;
    private boolean estadoMesa; //mesas activas o inactivas;

    public Mesa() {
    }

    public Mesa(int numMesa, int capacidad, boolean disponibilidad, boolean estadoMesa) {
        this.numMesa = numMesa;
        this.capacidad = capacidad;
        this.disponibilidad = disponibilidad;
        this.estadoMesa = estadoMesa;
    }

    public Mesa(int idMesa, int numMesa, int capacidad, boolean disponibilidad, boolean estadoMesa) {
        this.idMesa = idMesa;
        this.numMesa = numMesa;
        this.capacidad = capacidad;
        this.disponibilidad = disponibilidad;
        this.estadoMesa = estadoMesa;
    }

    public int getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(int idMesa) {
        this.idMesa = idMesa;
    }
    
    public int getNumMesa() {
        return numMesa;
    }

    public void setNumMesa(int numMesa) {
        this.numMesa = numMesa;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public boolean isDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(boolean disponibilidad) {
        this.disponibilidad = disponibilidad;
    }

    public boolean isEstadoMesa() {
        return estadoMesa;
    }

    public void setEstadoMesa(boolean estadoMesa) {
        this.estadoMesa = estadoMesa;
    }


    @Override
    public String toString() {
        return "############### \nMesa " + idMesa + "\nNumMesa: " + numMesa + "\nCapacidad: " + capacidad + "\nDisponibilidad: " + disponibilidad + "\nEstado: " + estadoMesa + "\n";
    }
    
}
