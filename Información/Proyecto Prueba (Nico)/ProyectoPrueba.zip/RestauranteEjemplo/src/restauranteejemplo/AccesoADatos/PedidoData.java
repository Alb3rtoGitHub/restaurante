/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restauranteejemplo.AccesoADatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import org.mariadb.jdbc.Statement;
import restauranteejemplo.entidades.Mesa;
import restauranteejemplo.entidades.Pedido;

/**
 *
 * @author Nico
 */
public class PedidoData {

    private Connection con = null;
    private MesaData mesaData;
    private PedidoProductoData ppd;

    public PedidoData() {
        con = Conexion.getConexion();
    }

    public void registrarPedido(Pedido pedido) {
        String sql = "INSERT INTO pedido (idMesa, nombreMesero, fechaHoraPedido, importe, cobrada) VALUES (?,?,?,null,?)";
        mesaData = new MesaData();
        ppd = new PedidoProductoData();
        try {
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            int idMesa = pedido.getMesa().getIdMesa();
            ps.setInt(1, idMesa);
            ps.setString(2, pedido.getNombreMesero());
            Timestamp fecha = Timestamp.valueOf(pedido.getFechaCreacion());
            ps.setTimestamp(3, fecha);
            ps.setBoolean(4, pedido.isCobrado()); //siempre false / no pago.
            if (mesaData.buscarMesa(idMesa).isDisponibilidad() == true) {
                int opcion = JOptionPane.showConfirmDialog(null, "¿Esta mesa esta libre, desea que pase a ocupada?", "Confirmar cambio de Disponibilidad", JOptionPane.YES_NO_OPTION);
                if (opcion == JOptionPane.YES_OPTION) {
                    Mesa mesita = mesaData.buscarMesa(idMesa);
                    mesita.setDisponibilidad(false);
                    mesaData.modificarMesa(mesita);
                    
                    ps.executeUpdate();
                    ResultSet res = ps.getGeneratedKeys();
                    if (res.next()) {
                        pedido.setIdPedido(res.getInt(1));
                        JOptionPane.showMessageDialog(null, "Pedido Registrado");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "La mesa ha quedado en Disponibilidad Libre, asi que el pedido no se hara!");
                }

            } else {
                ps.executeUpdate();
                ResultSet res = ps.getGeneratedKeys();
                if (res.next()) {
                    pedido.setIdPedido(res.getInt(1));
                    JOptionPane.showMessageDialog(null, "Pedido Registrado");
                }
            }
            ps.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a tabla Pedido " + ex.getMessage());
        }

        //FORMA 1
        //ps.setObject(3, pedido.getFechaCreacion)
        //FORMA 2
        //Otra forma es: Formatea el LocalDateTime como una cadena en el formato 'yyyy-MM-dd HH:mm:ss'
        //DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        //String fechaHoraFormatted = pedido.getFechaHora().format(formatter);
        //ps.setString(3, fechaHoraFormatted); // Establece la cadena formateada
    }

    public void modificarPedido(Pedido pedido) {
        String sql = "UPDATE pedido SET idMesa = ?, nombreMesero = ?, fechaHoraPedido = ?, cobrada = ? WHERE idPedido = ?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, pedido.getMesa().getIdMesa());
            ps.setString(2, pedido.getNombreMesero());
            Timestamp fecha = Timestamp.valueOf(pedido.getFechaCreacion());
            ps.setTimestamp(3, fecha);
            //ps.setDouble(4, pedido.getImporte());
            ps.setBoolean(4, false);
            ps.setInt(5, pedido.getIdPedido());

            int exito = ps.executeUpdate();
            if (exito == 1) {
                JOptionPane.showMessageDialog(null, "Pedido modificado.");
            } else {
                JOptionPane.showMessageDialog(null, "El Pedido no existe.");
            }
            ps.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a tabla pedido " + ex.getMessage());
        }
    }

    public void eliminarPedido(int idPedido) {
        int opcion = JOptionPane.showConfirmDialog(null, "¿Esta seguro que desea eliminar el pedido?", "Confirmar borrar pedido", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            String sql = "DELETE FROM pedido WHERE idPedido = ? AND cobrada = 0";

            try {
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setInt(1, idPedido);
                int exito = ps.executeUpdate();
                if (exito == 1) {
                    JOptionPane.showMessageDialog(null, "El pedido se elimino.");
                } else if (exito == 0) {
                    JOptionPane.showMessageDialog(null, "No se pudo eliminar el pedido. Aun no se encuentra pago.");
                }
                ps.close();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error al acceder a tabla pedido " + ex.getMessage());
            }

        }
    }

    public Pedido buscarPedido(int idPedido) {
        String sql = "SELECT idMesa, nombreMesero, fechaHoraPedido, importe, cobrada FROM pedido WHERE idPedido = ?";
        Pedido pedido = null;
        mesaData = new MesaData();

        try {

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idPedido);

            ResultSet res = ps.executeQuery();
            if (res.next()) {

                pedido = new Pedido();
                pedido.setIdPedido(idPedido);
                pedido.setMesa(mesaData.buscarMesa(res.getInt("idMesa")));
                pedido.setNombreMesero(res.getString("nombreMesero"));

                /*
                Recupera la columna 'fecha_hora' como Date y Time
                java.sql.Date date = rs.getDate("fecha_hora");
                java.sql.Time time = rs.getTime("fecha_hora");
                if (date != null && time != null) {
                LocalDateTime localDateTime = LocalDateTime.of(date.toLocalDate(), time.toLocalTime());
                pedido.setFechaHora(localDateTime);
                 */
                pedido.setFechaCreacion(res.getTimestamp("fechaHoraPedido").toLocalDateTime());
                pedido.setImporte(res.getDouble("importe"));
                pedido.setCobrado(res.getBoolean("cobrada"));

            } else {
                JOptionPane.showMessageDialog(null, "No existe ese pedido");
            }
            ps.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a tabla Pedido " + ex.getMessage());
        }
        return pedido;
    }

    public List<Pedido> listarPedidos() {
        ArrayList<Pedido> pedidos = new ArrayList<>();
        mesaData = new MesaData();

        String sql = "SELECT * FROM pedido";

        try {
            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet res = ps.executeQuery();

            while (res.next()) {

                Pedido pedido = new Pedido();
                pedido.setIdPedido(res.getInt("idPedido"));
                pedido.setMesa(mesaData.buscarMesa(res.getInt("idMesa")));
                pedido.setNombreMesero(res.getString("nombreMesero"));
                pedido.setFechaCreacion(res.getTimestamp("fechaHoraPedido").toLocalDateTime());
                pedido.setImporte(res.getDouble("importe"));
                pedido.setCobrado(res.getBoolean("cobrada"));

                pedidos.add(pedido);
            }
            if (pedidos.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No existen datos de pedidos");
            }
            ps.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }

        return pedidos;
    }

    public List<Pedido> listarPedidoPorMesa(int idMesa) {
        String sql = "SELECT * FROM pedido WHERE idMesa = ?";
        ArrayList<Pedido> pedidos = new ArrayList<>();
        mesaData = new MesaData();
        try {
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, idMesa);

            ResultSet res = ps.executeQuery();
            while (res.next()) {

                Pedido pedido = new Pedido();
                pedido.setIdPedido(res.getInt("idPedido"));
                pedido.setMesa(mesaData.buscarMesa(res.getInt("idMesa")));
                pedido.setNombreMesero(res.getString("nombreMesero"));
                pedido.setFechaCreacion(res.getTimestamp("fechaHoraPedido").toLocalDateTime());
                pedido.setImporte(res.getDouble("importe"));
                pedido.setCobrado(res.getBoolean("cobrada"));

                pedidos.add(pedido);
            }
            ps.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }

        return pedidos;
    }
}
