/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restauranteejemplo.AccesoADatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import restauranteejemplo.entidades.Mesa;

/**
 *
 * @author Nico
 */
public class MesaData {

    private Connection con = null;

    public MesaData() {
        con = Conexion.getConexion();
    }

    public void guardarMesa(Mesa mesa) {
        String sql = "INSERT INTO mesa (numeroMesa, capacidad, disponibilidad, estadoMesa) VALUES (?,?,?,?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, mesa.getNumMesa());
            ps.setInt(2, mesa.getCapacidad());
            ps.setBoolean(3, mesa.isDisponibilidad());
            ps.setBoolean(4, mesa.isEstadoMesa());
            ps.executeUpdate();

            ResultSet res = ps.getGeneratedKeys();
            if (res.next()) {
                mesa.setIdMesa(res.getInt(1));
                JOptionPane.showMessageDialog(null, "Mesa agregada");
            }
            ps.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a tabla Mesa " + ex.getMessage());
        }
    }

    public void modificarMesa(Mesa mesa) {
        String sql = "UPDATE mesa SET numeroMesa = ?, capacidad = ?, disponibilidad = ?, estadoMesa = ? WHERE idMesa = ?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, mesa.getNumMesa());
            ps.setInt(2, mesa.getCapacidad());
            ps.setBoolean(3, mesa.isDisponibilidad());
            ps.setBoolean(4, mesa.isEstadoMesa());
            ps.setInt(5, mesa.getIdMesa());
            int exito = ps.executeUpdate();
            if (exito == 1) {
                JOptionPane.showMessageDialog(null, "La Mesa se modifico.");
            } else {
                JOptionPane.showMessageDialog(null, "La Mesa no existe");
            }
            ps.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a tabla Mesa " + ex.getMessage());
        }
    }

    public void eliminarMesa(int idMesa) {
        int opcion = JOptionPane.showConfirmDialog(null, "¿Esta seguro que desea eliminar la Mesa?", "Confirmar borrar Mesa", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            String sql = "UPDATE mesa SET estadoMesa = 0 WHERE idMesa = ? AND idMesa NOT IN(SELECT idMesa FROM mesa WHERE disponibilidad = 0)";
            try {
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setInt(1, idMesa);
                int exito = ps.executeUpdate();
                if (exito == 1) {
                    JOptionPane.showMessageDialog(null, "La mesa se elimino.");
                } else if (exito == 0) {
                    JOptionPane.showMessageDialog(null, "No se pudo eliminar la mesa. Se encuentra ocupada ahora mismo.");
                }
                ps.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error al acceder a tabla mesa " + ex.getMessage());
            }
        }
    }

    public Mesa buscarMesa(int idMesa) {
        String sql = "SELECT numeroMesa, capacidad, disponibilidad, estadoMesa FROM mesa WHERE idMesa = ? AND estadoMesa = 1";
        Mesa mesa = null;
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idMesa);
            ResultSet res = ps.executeQuery();
            if (res.next()) {

                mesa = new Mesa();
                mesa.setIdMesa(idMesa);
                mesa.setNumMesa(res.getInt("numeroMesa"));
                mesa.setCapacidad(res.getInt("capacidad"));
                mesa.setDisponibilidad(res.getBoolean("disponibilidad"));
                mesa.setEstadoMesa(res.getBoolean("estadoMesa"));

            } else {
                JOptionPane.showMessageDialog(null, "No existe esa mesa");
            }
            ps.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a tabla Mesa " + ex.getMessage());
        }

        return mesa;
    }

    public Mesa buscarMesaPorNumero(int numeroMesa) {
        String sql = "SELECT idMesa, capacidad, disponibilidad, estadoMesa FROM mesa WHERE numeroMesa = ? AND estadoMesa = 1";
        Mesa mesa = null;
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, numeroMesa);
            ResultSet res = ps.executeQuery();
            if (res.next()) {

                mesa = new Mesa();
                mesa.setIdMesa(res.getInt("idMesa"));
                mesa.setNumMesa(numeroMesa);
                mesa.setCapacidad(res.getInt("capacidad"));
                mesa.setDisponibilidad(res.getBoolean("disponibilidad"));
                mesa.setEstadoMesa(res.getBoolean("estadoMesa"));
            }
            ps.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a tabla Mesa " + ex.getMessage());
        }

        return mesa;
    }

    public List<Mesa> listarMesas() {
        String sql = "SELECT * FROM mesa WHERE estadoMesa = 1";
        ArrayList<Mesa> mesas = new ArrayList<>();
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet res = ps.executeQuery();
            while (res.next()) {

                Mesa mesa = new Mesa();
                mesa.setIdMesa(res.getInt("idMesa"));
                mesa.setNumMesa(res.getInt("numeroMesa"));
                mesa.setCapacidad(res.getInt("capacidad"));
                mesa.setDisponibilidad(res.getBoolean("disponibilidad"));
                mesa.setEstadoMesa(true);

                mesas.add(mesa);
            }
            ps.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a tabla Mesa " + ex.getMessage());
        }

        return mesas;
    }
}
