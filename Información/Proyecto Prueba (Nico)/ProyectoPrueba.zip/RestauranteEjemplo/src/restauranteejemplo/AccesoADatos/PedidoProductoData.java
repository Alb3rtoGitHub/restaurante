/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restauranteejemplo.AccesoADatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import org.mariadb.jdbc.Statement;
import restauranteejemplo.entidades.Pedido;
import restauranteejemplo.entidades.PedidoProducto;

/**
 *
 * @author Nico
 */
public class PedidoProductoData {
    private Connection con = null;
    private PedidoData pedidodata;
    private ProductoData productodata;
    
    public PedidoProductoData(){
        con = Conexion.getConexion();
    }
    
    public void agregarPedidoProducto(PedidoProducto pp){
        String sql = "INSERT INTO pedidoproducto (idPedido, idProducto, cantidad) VALUES (?,?,?)";
        
        try{
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, pp.getPedido().getIdPedido());
            ps.setInt(2, pp.getProducto().getIdProducto());
            ps.setInt(3, pp.getCantidad());
            
            ps.executeUpdate();
            
            ResultSet res = ps.getGeneratedKeys();
            if (res.next()) {
                pp.setIdPedidoProducto(res.getInt(1));
                JOptionPane.showMessageDialog(null, "Pedido y Producto registrado!");
            }
            ps.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla PedidoProducto " + ex.getMessage());
        }
    }
    
    public void modificarPedidoConProducto(PedidoProducto pp){
        String sql = "UPDATE pedidoproducto SET idPedido = ?, idProducto = ?, cantidad = ? WHERE idPedProducto = ?";
        try{
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, pp.getPedido().getIdPedido());
            ps.setInt(2, pp.getProducto().getIdProducto());
            ps.setInt(3, pp.getCantidad());
            ps.setInt(4, pp.getIdPedidoProducto());
            
            int exito = ps.executeUpdate();
            if (exito == 1) {
                JOptionPane.showMessageDialog(null, "El pedido con producto se ha modificado");
            } else {
                JOptionPane.showMessageDialog(null, "El pedido con producto no existe");
            }
            ps.close();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a tabla pedido producto " + ex.getMessage());
        }
    }
    
    public void eliminarPedidoConProducto(int idPP){
        String sql = "DELETE FROM pedidoproducto WHERE idPedProducto = ? ";
        
        try{
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idPP);
            int exito = ps.executeUpdate();
            
            if (exito == 1) {
                JOptionPane.showMessageDialog(null, "Se ha eliminado el Pedido Con Producto exito!");
            } 
            ps.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla Pedido Producto " + ex.getMessage());
        }
    }
    
    public PedidoProducto buscarPedidoConProducto(int idPP){
        String sql = "SELECT idPedido, idProducto, cantidad FROM pedidoproducto WHERE idPedProducto = ?";
        PedidoProducto pedidoproduc = null;
        pedidodata = new PedidoData();
        productodata = new ProductoData();
        
        try{
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idPP);
            ResultSet res = ps.executeQuery();
            if (res.next()) {
                
                pedidoproduc = new PedidoProducto();
                pedidoproduc.setIdPedidoProducto(idPP);
                pedidoproduc.setPedido(pedidodata.buscarPedido(res.getInt("idPedido")));
                pedidoproduc.setProducto(productodata.buscarProducto(res.getInt("idProducto")));
                pedidoproduc.setCantidad(res.getInt("cantidad"));
                
            } else {
                JOptionPane.showMessageDialog(null, "No existe ese pedido producto");
            }
            ps.close();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a tabla pedido producto " + ex.getMessage());
        }
        
        return pedidoproduc;
    }
    
    public List<PedidoProducto> obtenerPedidosConProductos(){
        String sql = "SELECT * FROM pedidoproducto";
        pedidodata = new PedidoData();
        productodata = new ProductoData();
        ArrayList<PedidoProducto> pedidosconproductos = new ArrayList<>();
        try{
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet res = ps.executeQuery();
            while(res.next()){
                
                PedidoProducto pedidop = new PedidoProducto();
                pedidop.setIdPedidoProducto(res.getInt("idPedProducto"));
                pedidop.setPedido(pedidodata.buscarPedido(res.getInt("idPedido")));
                pedidop.setProducto(productodata.buscarProducto(res.getInt("idProducto")));
                pedidop.setCantidad(res.getInt("cantidad"));
                
                pedidosconproductos.add(pedidop);
            }
            ps.close();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a tabla Pedido Producto " + ex.getMessage());
        }
        
        return pedidosconproductos;
    }
    
    public List<Pedido> obtenerPedidosXMesero(String mesero){
        //¿Este puede ir en la clase Pedido? o tiene que traer los PedidoProductos que este atendiendo?
        MesaData mesadata = new MesaData();
        
        ArrayList<Pedido> listaPedidosXMesero = new ArrayList<>(); 
        String sql = "SELECT idPedido, idMesa, nombreMesero, fechaHoraPedido, importe, cobrada FROM Pedido WHERE nombreMesero = ?";
        
        try{
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, mesero);
            ResultSet res = ps.executeQuery();
            
            while(res.next()){
                Pedido pedido = new Pedido();
                pedido.setIdPedido(res.getInt("idPedido"));
                pedido.setMesa(mesadata.buscarMesa(res.getInt("idMesa")));
                pedido.setNombreMesero(mesero);
                pedido.setFechaCreacion(res.getTimestamp("fechaHoraPedido").toLocalDateTime());
                pedido.setImporte(res.getDouble("importe"));
                pedido.setCobrado(res.getBoolean("cobrada"));
                
                listaPedidosXMesero.add(pedido);
            }
            ps.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a tabla Pedido Producto " + ex.getMessage());
        }
        
        return listaPedidosXMesero;
    }   
    /*
    public List<PedidoProducto> obtenerPedidosXMesero(String mesero){
        //¿Este puede ir en la clase Pedido? o tiene que traer los PedidoProductos que este atendiendo?
        pedidodata = new PedidoData();
        productodata = new ProductoData();
        ArrayList<PedidoProducto> listaPedidosXMesero = new ArrayList<>(); 
        String sql = "SELECT p.idPedido, p.nombreMesero, pp.idPedProducto, pp.idProducto, pp.cantidad FROM Pedido p INNER JOIN PedidoProducto pp ON (p.idPedido = pp.idPedido) WHERE p.nombreMesero = ?";
        
        try{
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, mesero);
            ResultSet res = ps.executeQuery();
            
            while(res.next()){
                PedidoProducto pedidoconproducto = new PedidoProducto();
                pedidoconproducto.setIdPedidoProducto(res.getInt("idPedProducto"));
                pedidoconproducto.setPedido(pedidodata.buscarPedido(res.getInt("idPedido")));
                pedidoconproducto.setProducto(productodata.buscarProducto(res.getInt("idProducto")));
                pedidoconproducto.setCantidad(res.getInt("cantidad"));
                
                listaPedidosXMesero.add(pedidoconproducto);
            }
            ps.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a tabla Pedido Producto " + ex.getMessage());
        }
        
        return listaPedidosXMesero;
    }   
    */
    public double calcularSubtotal(int idPedProducto){
        String sql = "SELECT (p.precio * pp.cantidad) AS subtotal FROM pedidoproducto pp INNER JOIN producto p ON (pp.idProducto = p.idProducto) WHERE pp.idPedProducto = ?";
        double subtotal = 0;
        try{
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idPedProducto);
            ResultSet res = ps.executeQuery();
            
            if(res.next()){
                subtotal = res.getDouble("subtotal");
            }
            ps.close();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a tabla Pedido Producto " + ex.getMessage());
        }
        return subtotal;
    }
    
    
    public double calcularTotal(int idMesa, int idPedido){
        String sql = "SELECT (pr.precio * pp.cantidad) AS subtotal FROM pedidoproducto pp INNER JOIN producto pr ON (pp.idProducto = pr.idProducto) INNER JOIN pedido pe ON (pp.idPedido = pe.idPedido) WHERE pp.idPedido = ? AND pe.idMesa = ?";
        double subtotal = 0, total = 0;
        
        try{
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idPedido);
            ps.setInt(2, idMesa);
            ResultSet res = ps.executeQuery();
            while(res.next()){
                subtotal = res.getDouble("subtotal");
                total += subtotal;
                
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla Pedido Producto " + ex.getMessage());
        }
        
        return total;
    }
    
 
    public double precioTotalXFecha(LocalDate fecha){
        String sql = "SELECT (pr.precio * pp.cantidad) AS subtotal FROM pedidoproducto pp INNER JOIN producto pr ON (pp.idProducto = pr.idProducto) INNER JOIN pedido pe ON (pp.idPedido = pe.idPedido) WHERE (Date (pe.fechaHoraPedido) = ?)";
        double subtotal = 0, total = 0;
        
        try{
            PreparedStatement ps = con.prepareStatement(sql);
            
            ps.setString(1, fecha.toString());
            
            ResultSet res = ps.executeQuery();
            while(res.next()){
                subtotal = res.getDouble("subtotal");
                total += subtotal;
                
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a tabla Pedido Producto " + ex.getMessage());
        }
        
        return total;
    }
    
    
    public List<Pedido> listarPedidosXMeseroYFecha(String mesero, LocalDate fecha){
        MesaData mesadata = new MesaData();
        
        ArrayList<Pedido> listaPedidosXMesero = new ArrayList<>(); 
        String sql = "SELECT * FROM pedido WHERE nombreMesero = ? AND (Date (fechaHoraPedido) = ?)";
        
        try{
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, mesero);
            ps.setString(2, fecha.toString());
            ResultSet res = ps.executeQuery();
            
            while(res.next()){
                Pedido pedido = new Pedido();
                pedido.setIdPedido(res.getInt("idPedido"));
                pedido.setMesa(mesadata.buscarMesa(res.getInt("idMesa")));
                pedido.setNombreMesero(mesero);
                pedido.setFechaCreacion(res.getTimestamp("fechaHoraPedido").toLocalDateTime());
                pedido.setImporte(res.getDouble("importe"));
                pedido.setCobrado(res.getBoolean("cobrada"));
                
                listaPedidosXMesero.add(pedido);
            }
            ps.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a tabla Pedido Producto " + ex.getMessage());
        }
        
        return listaPedidosXMesero;
    }
    
    public List<Pedido> listarPedidosXMesaEntreFechaYHora(int idM, LocalDateTime fecha1, LocalDateTime fecha2){
        MesaData mesadata = new MesaData();
        
        ArrayList<Pedido> listaPedidosMesaXFH = new ArrayList<>(); 
        String sql = "SELECT p.idPedido, p.idMesa, p.nombreMesero, p.fechaHoraPedido, p.importe, p.cobrada FROM pedido p INNER JOIN mesa m ON (p.idMesa = m.idMesa) WHERE m.idMesa = ? AND (p.fechaHoraPedido BETWEEN ? AND ?)";
        
        try{
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idM);
            Timestamp fechaA = Timestamp.valueOf(fecha1);
            Timestamp fechaB = Timestamp.valueOf(fecha2);
            ps.setTimestamp(2, fechaA);
            ps.setTimestamp(3, fechaB);
            
            ResultSet res = ps.executeQuery();
            
            while(res.next()){
                Pedido pedido = new Pedido();
                pedido.setIdPedido(res.getInt("idPedido"));
                pedido.setMesa(mesadata.buscarMesa(res.getInt("p.idMesa")));
                pedido.setNombreMesero(res.getString("nombreMesero"));
                pedido.setFechaCreacion(res.getTimestamp("fechaHoraPedido").toLocalDateTime());
                pedido.setImporte(res.getDouble("importe"));
                pedido.setCobrado(res.getBoolean("cobrada"));
                
                listaPedidosMesaXFH.add(pedido);
            }
            ps.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a tabla Pedido Producto " + ex.getMessage());
        }
        
        return listaPedidosMesaXFH;
    }
    
}
